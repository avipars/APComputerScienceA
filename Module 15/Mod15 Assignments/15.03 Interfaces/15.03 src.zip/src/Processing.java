/**
 * This is the Interface that maps out the amount of reading done.
 * @author Ricky Mutschlechner
 * @version 1/18/2011
 *
 */
public interface Processing {

public abstract void doReading();

}
