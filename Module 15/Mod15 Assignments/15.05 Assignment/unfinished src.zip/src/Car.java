
public class Car extends Vehicle {
	
	public Car(String name, int cost){
		super(name, cost);
	}

}
