import java.util.ArrayList;
public class InventoryDemo {

		public static void main(String[] args){
			ArrayList<Tool> t = new ArrayList<Tool>();
			
			Car c = new Car("BMW", 125000);
			Truck tr = new Truck("Chevy Silverado", 27000);
			
}
		
}
